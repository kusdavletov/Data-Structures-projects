# ifndef HASHMAP_H
# define HASHMAP_H

# include <iostream>
# include <sstream>
# include <string>
# include <vector>
# include <algorithm>
# include <fstream>

typedef unsigned int uint;

/**
  * Assignment 6 for CSE221 Data Structures
  *
  * 2015. 11. 17
  *
  */

// Map element
template <class KeyType, class ValType>
class MapElem
{
public:
	typedef KeyType ktype;
	typedef ValType vtype;

	KeyType key;
	ValType val;

	MapElem* link;

	MapElem <KeyType, ValType> (KeyType k, ValType v, MapElem* l = NULL)
	{
	    key = k;
	    val = v;
	    link = l;
	};
	MapElem <KeyType, ValType> () {};
};

bool inline operator==(std::string a, std::string b)
{
	if((a).compare(b) == 0) return true;
	return false;
}

//
// Hash Map data structure
//
template <class HashMapElemType>
class HashMap
{
public:
	typedef typename HashMapElemType::ktype KeyType;
	typedef typename HashMapElemType::vtype ValType;

	// constructor
	HashMap(unsigned int c = 1000);

	// destructor
	~HashMap();

	// Modify below functions
	uint size() { return mapsize; };

	bool isEmpty() { return (mapsize == 0); };

	// ToDo
	HashMapElemType* find(const KeyType k);

	void insert(const KeyType k, const ValType v);

	bool remove(const KeyType k);

	uint hashfunction(const KeyType k);

	void print();

private:
	// Hash Table
	HashMapElemType** ht;

	uint mapsize, capacity, divisor;
};

//
// - Implementation -
//

// constructor
template <class HashMapElemType>
HashMap<HashMapElemType>::HashMap(uint c)
{
    capacity = c;

    // change `c` to a smallest prime number less or equal to `c`
    for (int i = c; i > 3; --i)
    {
        bool prime = true;
        for (int j = 2; j * j <= i; ++j)
            if (i % j == 0)
            {
                prime = false;
                break;
            }
        if (prime)
        {
            c = i;
            break;
        }
    }

    mapsize = 0;
    divisor = c;
	ht = new HashMapElemType* [capacity];

	for (int i = 0; i < capacity; ++i)
	{
        ht[i] = new HashMapElemType;
        ht[i] -> link = NULL;
	}
}

// destructor
template <class HashMapElemType>
HashMap<HashMapElemType>::~HashMap()
{
	delete ht;
}

template <class HashMapElemType>
HashMapElemType*
HashMap<HashMapElemType>::find(const KeyType k)
{
    uint h = hashfunction (k) % divisor;
    for (HashMapElemType *i = ht[h]; i -> link != NULL; i = i -> link)
        if (i -> link -> key == k)
            return i -> link;
    return NULL;
}

template <class HashMapElemType>
void
HashMap<HashMapElemType>::insert(const KeyType k, const ValType v)
{
    remove (k);
    uint h = hashfunction (k) % divisor;
    HashMapElemType *x = new HashMapElemType (k, v, ht[h] -> link);
    ht[h] -> link = x;
    ++mapsize;
}

template <class HashMapElemType>
bool
HashMap<HashMapElemType>::remove(const KeyType k)
{
    uint h = hashfunction (k) % divisor;
    for (HashMapElemType *i = ht[h]; i -> link != NULL; i = i -> link)
        if (i -> link -> key == k)
        {
            if (i -> link -> link != NULL)
                i -> link = i -> link -> link;
            else
                i -> link = NULL;
            return true;
        }
    return false;
}

template <class HashMapElemType>
uint
HashMap<HashMapElemType>::hashfunction(const KeyType k)
{
	std :: stringstream stream;
	stream << k;
	std :: string s = stream.str ();
	uint n = s.size (), res = 0, start = 0;

    if (n & 1)
    {
        res = (uint (s[0]) + 1);
        start = 1;
    }

    for (uint i = start; i < n; i += 2)
        res += ((uint (s[i]) + 1) << 8) + uint (s[i + 1]) + 1;

	return res;
}

template <class HashMapElemType>
void
HashMap<HashMapElemType>::print()
{
    int k = 0;
    std :: vector < std :: pair < ValType, KeyType > > st (mapsize);
	for (int i = 0; i < capacity; ++i)
        for (HashMapElemType *j = ht[i] -> link; j != NULL; j = j -> link)
            st[k++] = make_pair (j -> val, j -> key);
    std :: sort (st.begin (), st.end ());
    for (int i = 0; i < mapsize; ++i)
        std :: cout << st[i].second << " " << st[i].first << "\n";
}

#endif
