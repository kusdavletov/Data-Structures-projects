# include "hashmap.h"

using namespace std;

HashMap < MapElem < string, uint > > st (1000);

void spellcheck(std::string s)
{
	cout << "> " << s << " is";
	bool check = (st.find (s) != NULL);
	cout << (check ? "" : " NOT") << " in the dictionary\n";
	if (check) return;

	cout << "> " << s << " : ";
	int n = s.size ();
	bool first = false;

	for (int i = 0; i < n; ++i)
        for (char j = 'a'; j <= 'z'; ++j)
            if (s[i] != j)
            {
                swap (s[i], j);
                check = (st.find (s) != NULL);
                if (check)
                {
                    cout << (first ? ", " : " ") << s;
                    first = true;
                }
                swap (s[i], j);
            }
    cout << (first ? "\n" : " no suggestion\n");
}


int main()
{
	// load dictionary
	char filename[] = "dictionary.txt";
	std::ifstream ifs(filename, std::ifstream::in);
	std::string s((std::istreambuf_iterator<char>(ifs)), std::istreambuf_iterator<char>());
	std::transform(s.begin(), s.end(),
				   s.begin(), ::tolower);

	std::string token;
	unsigned int len = s.length();

	for(int i=0; i<len; i++)
	{
		int ascii = s[i];

		if(ascii < 97 || ascii > 127)
		{
			if(token.length() > 0)
			{
			    st.insert (token, rand ());
				token.clear();
			}
			continue;
		}
		token.push_back(s[i]);
	}

	//
	// infinite loop to accept user input word
	//
	while(1)
	{
		std::string s;
		std::cout << "> ";
		std::cin >> s;
		if(s == "q") break;
		spellcheck( s );
	}

	return 0;
}
