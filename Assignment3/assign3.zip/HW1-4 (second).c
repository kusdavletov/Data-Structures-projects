//Kusdavletov Ernar
#include <stdio.h>

struct Distance{
    int cm;
    float meter;
};

int main(){
    struct Distance first, second;
    printf("Enter information for 1st distance\n");
    printf("Enter cm: ");
    scanf("%d", &first.cm);
    printf("Enter meter: ");
    scanf("%f", &first.meter);
    printf("\nEnter information for 2nd distance\n");
    printf("Enter cm: ");
    scanf("%d", &second.cm);
    printf("Enter meter: ");
    scanf("%f", &second.meter);
    printf("\nSum of distances: %d-%0.1f\n", (first.cm + second.cm), (first.meter + second.meter));
    return 0;
}
