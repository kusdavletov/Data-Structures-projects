//
// ArrayCompleteTree.h  (Version 1.1)
//
// Kusdavletov Ernar, 20152008, kusdavletov1@unist.ac.kr
//

#ifndef ASSIGNMENT3_ARRAYCOMPLETETREE_H
#define ASSIGNMENT3_ARRAYCOMPLETETREE_H

// You are *not* allowed to include other header files

#include <iostream>
#include <stdexcept>

using namespace std;

template<typename E>
class ArrayCompleteTree {       //not allowed to define any other member variables (public, private, or protected)
public:                         //not allowed to define any public member functions or other classes

    class Locator {             //not allowed to define any other member variables (public, private, or protected)
        int i;                  // the index of the location-aware entry in v

        public:
            Locator(int _i){
                i = _i;
            }
            friend class ArrayCompleteTree;
    };

    class LocationAwareEntry {  //not allowed to define any other member variables (public, private, or protected)
        E e;                    // the element
        Locator *loc;           // a pointer to the locator of this entry

        public:
            LocationAwareEntry(){
                loc = NULL;
            }
            LocationAwareEntry(E _e, int i){
                e = _e;
                Locator *new_loc = new Locator(i);
                loc = new_loc;
            }
            LocationAwareEntry(const LocationAwareEntry& entry){
                e = entry.e;
                Locator *new_loc = new Locator(entry.loc->i);
                loc = new_loc;
            }
            ~LocationAwareEntry(){
                clear();
            }
            LocationAwareEntry& operator=(const LocationAwareEntry& entry){
                if(loc != NULL)
                    clear();
                e = entry.e;
                Locator *new_loc = new Locator(entry.loc->i);
                loc = new_loc;
            }
            void clear(){
                Locator* temp = loc;
                delete temp;
                loc = NULL;
            }
            friend class ArrayCompleteTree;
    };

    class Position {
        const ArrayCompleteTree* tree;      // a pointer to the ArrayCompleteTree object that this position object works for.

        public:
            Locator *loc;                       // a pointer to the locator object of the entry pointed by this Position object.
            Position(){
                tree = NULL;
                loc = NULL;
            }
            Position(const ArrayCompleteTree *_tree, Locator *_loc){
                tree = _tree;
                loc = _loc;
            }
            E& operator*() const{
                if (tree == NULL || loc == NULL) throw runtime_error("Cannot apply *operator to NULL position");
                return tree->v[loc->i].e;
            }
            bool operator==(const Position& p) const{
                return (loc == NULL && p.loc == NULL) || ((tree == p.tree) && (loc == p.loc));
            }
            friend class ArrayCompleteTree;
    };

private:
    LocationAwareEntry* v;   // the array of location-aware entries
    int vsize;               // the size of v
    int n;                   // the number of used entries in v

public:
    ArrayCompleteTree(int _vsize = 10){
        vsize = _vsize;
        n = 0;
        v = new LocationAwareEntry[vsize];
    }
    ArrayCompleteTree(const ArrayCompleteTree& t){
        //Notice that you will have to duplicate v and the Locator objects (via the copy constructor of LocationAwareEntry) in the copy constructor.
        vsize = t.vsize;
        n = t.n;
        v = new LocationAwareEntry[vsize];
        for(int i = 0; i < n; i++){
			v[i] = LocationAwareEntry(t.v->e, i);
		}
    }
    ~ArrayCompleteTree(){
        for (int i = 0; i < vsize; i++){
            v[i].clear();
        }
        vsize = 0;
        n = 0;
        delete[] v;
    }
    int size() const{
        return n;
    }
    Position left(const Position& p) const{
        if (p.loc == NULL || (2 * p.loc->i + 1 >= n)) throw runtime_error("Locator of the position is NULL or index is out of range.");
        return Position(this, v[2 * p.loc->i + 1].loc);
    }
    Position right(const Position& p) const{
        if (p.loc == NULL || (2 * p.loc->i + 2 >= n)) throw runtime_error("Locator of the position is NULL or index is out of range.");
        return Position(this, v[2 * p.loc->i + 2].loc);
    }
    Position parent(const Position& p) const{
        if (p.loc == NULL || ((p.loc->i - 1) / 2 > n) || isRoot(p)) throw runtime_error("Locator of the position is NULL or index is out of range.");
        return Position(this, v[(p.loc->i - 1) / 2].loc);
    }
    bool hasLeft(const Position& p) const{
        if (p.loc == NULL) throw runtime_error("Locator of the position is NULL.");
        return 2 * p.loc->i + 1 < n;
    }
    bool hasRight(const Position& p) const{
        if (p.loc == NULL) throw runtime_error("Locator of the position is NULL.");
        return 2 * p.loc->i + 2 < n;
    }
    bool isRoot(const Position& p) const{
        if (p.loc == NULL) throw runtime_error("Locator of the position is NULL.");
		return p == Position(this, v[0].loc);
    }
    Position root(){
        if (v[0].loc == NULL) throw runtime_error("Array is empty.");
		return Position(this, v[0].loc);
    }
    Position last(){
        if (v[0].loc == NULL) throw runtime_error("Array is empty.");
        return Position(this, v[n - 1].loc);
    }
    void addLast(const E& e){
        // Remember to free the memory of the previous v and the Locator objects (once again, via the destructor of LocationAwareEntry) after resizing.
        if (n >= vsize){
            LocationAwareEntry *new_array = new LocationAwareEntry[2 * vsize];
            for (int i = 0; i < n; i++){
                new_array[i] = v[i];
                v[i].clear();
            }
            v = new_array;
        }
        *(v + n) = LocationAwareEntry(e, n);
        n = n + 1;
        vsize = 2 * vsize;
    }
    void removeLast(){
        if (v[0].loc == NULL) throw runtime_error("Array is empty.");
        v[n - 1].clear();
        n = n - 1;
    }
    void swap(const Position& p, const Position& q){
        if (p.loc == NULL || q.loc == NULL) throw runtime_error("Locator of the position is NULL.");

        E temp = *q;
        *q = *p;
        *p = temp;
    }
    void cleanup(){
        for (int i = n; i < vsize; i++){
            v[i].clear();
        }
        vsize = n;
    }
};

#endif //ASSIGNMENT3_ARRAYCOMPLETETREE_H
