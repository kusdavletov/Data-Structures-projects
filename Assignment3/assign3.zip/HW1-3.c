//Kusdavletov Ernar
#include <stdio.h>
#include <string.h>

int exist(char *sentence_exist, char *str_exist){
    int len_sentence_exist, len_str_exist;
    len_sentence_exist = strlen(sentence_exist);
    len_str_exist = strlen(str_exist);
    int i, j, checker = 0;
    for (i = 0; i < len_sentence_exist - len_str_exist; i++){
        if (sentence_exist[i] == ' ' || i == 0){
            if (sentence_exist[i] == ' ')
                i = i + 1;
            for (j = 0; j < len_str_exist; j++){
                if (sentence_exist[i + j] == str_exist[j])
                    checker += 1;
                else {
                    checker = 0;
                    break;
                }
            }
        }
        if (checker == len_str_exist && (sentence_exist[i + len_str_exist] == ' ' || ((i + len_str_exist) == len_sentence_exist)))
            return i;
        checker = 0;
    }
    return -1;
}

void substract(char *sentence_substract, char *str_substract){
    int len_sentence_substract, len_str_substract;
    len_sentence_substract = strlen(sentence_substract);
    len_str_substract = strlen(str_substract);
    while (exist(sentence_substract, str_substract) != -1)
        memmove(sentence_substract + exist(sentence_substract, str_substract), sentence_substract + exist(sentence_substract, str_substract) + len_str_substract, len_sentence_substract - len_str_substract + 1);
}

void reverse(char *sentence_reverse){
   char temp, *first, *second;
   int len, i;
   len = strlen(sentence_reverse);
   first = sentence_reverse;
   second = sentence_reverse + (len - 1);
   for (i = 0; i < (len / 2); i++){
      temp = *second;
      *second = *first;
      *first = temp;
      first++;
      second--;
   }
}

int main(){
    char sentence[1000], str[100];
    printf("Enter a sentence: ");
    scanf("%[^'\n']s", sentence);
    printf("Enter string: ");
    scanf("%s", str);
    strcat(sentence, str);
    printf("After: %s", sentence);
    printf("\nEnter string: ");
    scanf("%s", str);
    substract(sentence, str);
    printf("After: %s", sentence);
    reverse(sentence);
    printf("\nAfter: %s", sentence);
    return 0;
}
