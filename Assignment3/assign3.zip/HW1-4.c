//Kusdavletov Ernar
#include <stdio.h>

int main(){
    FILE *hello;
    hello = fopen("hello.txt", "w+");
    char str[1000];
    printf("Enter sentence: \n");
    scanf("%[^'\n']s",str);
    fputs(str, hello);
    fclose(hello);
    return 0;
}
