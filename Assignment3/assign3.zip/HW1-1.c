//Kusdavletov Ernar
#include <stdio.h>

void swap(int *x, int *y, int *z){
    int arr[3] = {*x, *y, *z};
    int i, j, temp;
    for (i = 0; i < 3; i++){
        for (j = i + 1; j < 3; j++){
            if (arr[i] > arr[j]){
                temp =  arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
    *x = arr[0];
    *y = arr[1];
    *z = arr[2];
}

int main(){
    int a, b, c;
    printf("Enter a, b and c respectively: ");
    scanf("%d %d %d", &a, &b, &c);
    swap(&a, &b, &c);
    printf("\nValue after swapping: \na = %d \nb = %d \nc = %d", a, b, c);
    return 0;
}
