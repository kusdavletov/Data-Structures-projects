//Kusdavletov Ernar
#include <stdio.h>
#include <stdlib.h>

struct Record{
    char field[100];
    int number;
};

int main(){
    int i, num;
    printf("Enter number of records: ");
    scanf("%d", &num);
    struct Record *arr;
    arr = calloc(num, sizeof(int));
    for (i = 1; i <= num; i++){
        scanf("%s", arr[i].field);
        scanf("%d", &arr[i].number);
    }
    printf("\nDisplaying Information:\n");
    for (i = 1; i <= num; i++){
        printf("%s       ", arr[i].field);
        printf("%d\n", arr[i].number);
    }
    free(arr);
    return 0;
}
