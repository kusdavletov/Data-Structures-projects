//Kusdavletov Ernar
#include <stdio.h>
#include <stdlib.h>

int largest(int arr[], int size){
    int largest_value = arr[0];
    int i;
    for (i = 1; i < size; i++)
        if (arr[i] > largest_value)
            largest_value = arr[i];
    return largest_value;
}

int main(){
    int n, i, *arr;
    printf("Enter total number of elements: ");
    scanf("%d", &n);
    arr = calloc(n, sizeof(int));
    printf("\n");
    for (i = 1; i <= n; i++){
        printf("Enter Number %d: ", i);
        scanf("%d", (arr + i - 1));
    }
    printf("Largest element: %d", largest(arr, n));
    free(arr);
    return 0;
}
