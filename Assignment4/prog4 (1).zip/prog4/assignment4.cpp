//
// assignment4.h  (Version 1.0)
//
// Please write your name, your student ID, and your email here.
// Moreover, please describe the implementation of your functions here.
// You will have to submit this file.
//

#include <iostream>
#include <string>
#include <stdexcept>
#include <queue>
#include <list>
#include <vector>
#include <map>
#include <limits>
#include "AdjacencyListDirectedGraph.h"
#include "FlightMap.h"

double FlightMap::calcRouteDistance(const list < string > route) {
	double result = 0;
	string last = "";
	bool first = true;
	for(list < string > :: const_iterator iter = route.begin();iter != route.end();++ iter){
		if(isAirportExist(*iter) == false)
			throw runtime_error("calcRouteDistance: airport does not exist");
		if(!first){
			if(isConnectionExist(last, *iter) == false)
				throw runtime_error("calcRouteDistance: Connection does not exist");
			FlightGraph::Vertex from, to;
			findAirport(from, last);
			findAirport(to, *iter);
			FlightGraph::Edge e = from.outgoingEdge(to);
			result += *e;
		}
		first = false;
		last = *iter;
	}
	return result;
}

list < string > FlightMap::findReachableAirports(const string &airport) {
	if(isAirportExist(airport) == false)
		throw runtime_error("findReachableAirports: airport does not exist");	
	FlightGraph::Vertex v;
	findAirport(v, airport);
	FlightGraph::EdgeList adj = v.incidentEdges();
	list < string > res;
	for(FlightGraph::EdgeItor e = adj.begin();e != adj.end();++ e){
		string to = *(e -> opposite(v));
		res.push_back(to);
	}
	return res;
}


map < string , bool > used;
map < string , string > p;

void FlightMap::dfs(const string &airport){
	used[airport] = true;
	list < string > adj = findReachableAirports(airport);
	for(list < string > ::iterator to = adj.begin();to != adj.end();++ to){
		if(!used[*to]){
			p[*to] = airport;
			dfs(*to);
		}
	}
}

list < string > FlightMap::findRoute(const string &airport1, const string &airport2) {
	used.clear();
	p.clear();
	if(isAirportExist(airport1) == false || isAirportExist(airport2) == false)
		throw runtime_error("findRoute: at least one of the airports does not exist");
	dfs(airport1);
	if(used[airport2] == false)
		throw runtime_error("findRoute: there is no any route between airports");
	string cur = airport2;
	list < string > res;
	do {
		res.push_back(cur);
		if(cur == airport1)
			break;
		cur = p[cur];	
	}while(true);	
	res.reverse();
	return res;
}

map < string , double > d;
priority_queue < pair < double , string > > q;

void FlightMap::Dijkstra(const string &airport){
	if(isAirportExist(airport) == false)
		throw runtime_error("Dijkstra: airport does not exist");
	d.clear();
	p.clear();
	q.push(make_pair(0.0, airport));
	d[airport] = 0.0;
	while(!q.empty()){
		pair < double , string > cur = q.top();
		q.pop();
		if(d[cur.second] > cur.first)
			continue;
		list < string > adj = findReachableAirports(cur.second);
		FlightGraph::Vertex from, to;
		findAirport(from, cur.second);
		for(list < string > ::iterator it = adj.begin();it != adj.end();++ it){
			findAirport(to, *it);
			FlightGraph::Edge e = from.outgoingEdge(to);
			if(d.find(*it) == d.end() || d[*it] > d[cur.second] + *e){
				d[*it] = d[cur.second] + *e;
				p[*it] = cur.second;
				q.push(make_pair(d[*it] + d[cur.second] + *e, *it));
			}
		}
	}
}

list <string> FlightMap::findShortestRoute(const string &airport1, const string &airport2) {
	if(isAirportExist(airport1) == false || isAirportExist(airport2) == false)
		throw runtime_error("findShortestRoute: at least one of the airports doesn't exist");
	Dijkstra(airport1);
	list < string > res;
	string cur = airport2;
	do {
		res.push_back(cur);
		if(cur == airport1)
			break;
		cur = p[cur];
	}while(1);
	res.reverse();
	return res;
}


void FlightMap::printAllShortestRoutes(const string &airport) {
	if(isAirportExist(airport) == false)
		throw runtime_error("printAllShortestRoutes: airport does not exist");
	Dijkstra(airport);
	FlightGraph::Vertex v;
	findAirport(v, airport);
	FlightGraph::EdgeList adj = v.incidentEdges();
	list < string > res;
	for(FlightGraph::EdgeItor e = adj.begin();e != adj.end();++ e){
		string to = *(e -> opposite(v));
		list < string > all;
		do {
			all.push_back(to);
			if(to == airport)
				break;
			to = p[to];
		}while(true);
		all.reverse();
		printRoute(all);
		printf(" (Distance = %f)\n", calcRouteDistance(all));
	}
}

