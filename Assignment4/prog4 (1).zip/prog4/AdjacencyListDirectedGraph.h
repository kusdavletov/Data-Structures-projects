// AdjacencyListDirectedGraph.h  (Version 1.0)
//
// name   : Birzhan Auganov
// id     : 20161398
// e-mail : birzhan7777@gmail.com

#ifndef ASSIGNMENT5_ADJACENCYLISTDIRECTEDGRAPH_H
#define ASSIGNMENT5_ADJACENCYLISTDIRECTEDGRAPH_H

#include <iostream>
#include <list>
#include <stdexcept>

using namespace std;

template < typename V , typename E >
class AdjacencyListDirectedGraph {

	public:

  		class Vertex;
  		class Edge;

  		typedef list < Vertex > VertexList;
  		typedef list < Edge > EdgeList;
  		typedef typename VertexList::iterator VertexItor;
  		typedef typename EdgeList::iterator EdgeItor;
  		typedef typename VertexList::const_iterator VertexConstItor;
  		typedef typename EdgeList::const_iterator EdgeConstItor;

	private:

		struct VertexObject;
  		struct EdgeObject;

		typedef list < VertexObject > VertexObjectList;
  		typedef list < EdgeObject > EdgeObjectList;
  		typedef list < EdgeList > IncidenceEdgesList;

  		typedef typename VertexObjectList::iterator VertexObjectItor;
  		typedef typename EdgeObjectList::iterator EdgeObjectItor;
  		typedef typename IncidenceEdgesList::iterator IncidenceEdgesItor;

  		struct VertexObject {
    		V elt;                             // the element stored at this vertex
    		VertexObjectItor pos;              // position in vertex_collection
    		IncidenceEdgesItor inc_edges_pos;  // position in inc_edges_collection
			
    		VertexObject(V _elt) : elt(_elt) {}  // pos and inc_edges_pos are initially "NULL".
  		};

  		struct EdgeObject {
    		E elt;                          // the element stored at this edge
    		Vertex origin_vertex;           // the vertex at the origin
    		Vertex dest_vertex;             // the vertex at the destination
   		    EdgeObjectItor pos;             // position in edge_collection
   		    EdgeItor origin_inc_edges_pos;  // position in an edge list in inc_edges_collection
    		EdgeItor dest_inc_edges_pos;    // position in an edge list in inc_edges_collection

    		EdgeObject(const Vertex& v, const Vertex& w, E _elt) : origin_vertex(v), dest_vertex(w), elt(_elt) {} 
  		};

  		VertexObjectList vertex_collection;
  		EdgeObjectList edge_collection;
  		IncidenceEdgesList inc_edges_collection;

	public:

  		class Vertex {
			VertexObject *v_obj;
  			public:
    			Vertex(VertexObject* v = NULL) : v_obj(v) {}
    			
    			V& operator*() const {
					return v_obj -> elt;	
    			}

    			EdgeList incidentEdges() const {
					return *(v_obj -> inc_edges_pos);		
    			}

                bool isAdjacentTo(const Vertex& v) const {
					if(isOutgoingTo(v))
						return true;
					EdgeList adj = v.incidentEdges();
					for(EdgeItor adj_edge = adj.begin();adj_edge != adj.end();++ adj_edge)
						if(adj_edge -> e_obj -> dest_vertex.v_obj == v_obj)
							return true;
					return false;
				}

    			bool isOutgoingTo(const Vertex& v) const {
				    EdgeList adj = incidentEdges();
					for(EdgeItor adj_edge = adj.begin();adj_edge != adj.end();++ adj_edge)
						if(adj_edge -> e_obj -> dest_vertex.v_obj == v_obj)
							return true;
					return false;			 		
    			}

   				Edge outgoingEdge(const Vertex& v) const {
				    EdgeList adj = incidentEdges();
					for(EdgeItor adj_edge = adj.begin();adj_edge != adj.end();++ adj_edge)
						if(adj_edge -> e_obj -> dest_vertex.v_obj == v_obj)
							return *adj_edge;
					throw runtime_error("outgoingEdge: directed edge does not exist");
    			}

    			EdgeList outgoingEdges() const {
					return incidentEdges();		
    			}

    			bool operator == (const Vertex& v) const {
					return v_obj == v.v_obj;	
    			}

    			 friend class AdjacencyListDirectedGraph<V,E>;
  		};

  		 class Edge {

    	 	EdgeObject *e_obj;

  			public:

    			Edge(EdgeObject* e = NULL) : e_obj(e) {}

   			 	E& operator*() const {
					return e_obj -> elt;
    			}

    			VertexList endVertices() const {
					VertexList res;
					res.push_back(e_obj -> origin_vertex);
					res.push_back(e_obj -> dest_vertex);
					return res;
    			}	

    			Vertex opposite(const Vertex& v) const {
					if(e_obj -> origin_vertex == v)
						return e_obj -> dest_vertex;
					if(e_obj -> dest_vertex == v)
						return e_obj -> origin_vertex;
					throw runtime_error("opposite: neither oringin nor destination");
    			}

   			 	bool isAdjacentTo(const Edge& edge) const {
					return isIncidentOn(edge.origin()) || isIncidentOn(edge.dest());
    			}

   				bool isIncidentOn(const Vertex& v) const {
					return origin() == v || dest() == v;	
    			}

    			Vertex origin() const {
					return e_obj -> origin_vertex;
   			 	}

  			  	Vertex dest() const {
					return e_obj -> dest_vertex;
   			 	}

    			bool isDirected() const {
					return true;
    			}

   			 	bool operator == (const Edge& edge) const {
					return e_obj == edge.e_obj;
  			  	}

    			friend class AdjacencyListDirectedGraph<V,E>;
  		};


	public:

 		VertexList vertices() {
  			VertexList res;
			for(VertexObjectItor v = vertex_collection.begin();v != vertex_collection.end();++ v){
				VertexObject *hobbit;
				hobbit -> elt = (*v).elt;
				hobbit -> inc_edges_pos = (*v).inc_edges_pos;
				hobbit -> pos = (*v).pos;
				res.push_back(hobbit);
			}
			return res;
		}
  		EdgeList edges() {
  			EdgeList res;
			for(EdgeObjectItor e = edge_collection.begin();e != edge_collection.end();++ e){
				EdgeObject *fitch;
				fitch -> elt = (*e).elt;
				fitch -> origin_vertex = (*e).origin_vertex;
				fitch -> dest_vertex = (*e).dest_vertex;
				fitch -> pos = (*e).pos;
				fitch -> origin_inc_edges_pos = (*e).origin_inc_edges_pos;
				fitch -> dest_inc_edges_pos = (*e).dest_inc_edges_pos;
				res.push_back(fitch);
			}
			return res;	
  		}

  		Vertex insertVertex(const V& x) {
			VertexObject tmp_v(x);
			vertex_collection.push_back(tmp_v);
			
			EdgeList tmp_el;
			inc_edges_collection.push_back(tmp_el);
			
			IncidenceEdgesItor last2 = inc_edges_collection.end(); 
			VertexObjectItor last3 = vertex_collection.end();
			-- last3;
			-- last2;
			Vertex tmp_v2;
			tmp_v2.v_obj -> elt = x;
			tmp_v2.v_obj -> inc_edges_pos = last2;
			tmp_v2.v_obj -> pos = last3;
			return tmp_v2;
  		}

  		Edge insertDirectedEdge(const Vertex& v, const Vertex& w, E x) {
	    	EdgeList adj = v.incidentEdges();
			for(EdgeItor adj_edge = adj.begin();adj_edge != adj.end();++ adj_edge)
				if(adj_edge -> e_obj -> dest_vertex == w && adj_edge -> e_obj -> elt == x)
					throw runtime_error("insertDirectedEdge: already existed edge");
			EdgeObject tmp_e(v, w, x);
			edge_collection.push_back(tmp_e);
			EdgeObjectItor last = edge_collection.end();
			-- last;
			Edge e;
			e.e_obj -> elt = x;
			e.e_obj -> origin_vertex = v;
			e.e_obj -> dest_vertex = w;
			e.e_obj -> pos = last;
			EdgeList el = *(v.v_obj -> inc_edges_pos);
			el.push_back(e);
			EdgeItor last2 = el.end();
			-- last2;
			e.e_obj -> origin_inc_edges_pos = last2;
			return e;
  		}

  		void eraseVertex(const Vertex& v) {
			vertex_collection.erase(v.v_obj -> pos);			
			EdgeList adj = v.incidentEdges();
			for(EdgeItor it = adj.begin();it != adj.end();++ it)
				eraseEdge(*it);
		}

  		void eraseEdge(const Edge& e) {
			(*(e.e_obj -> origin_vertex.v_obj -> inc_edges_pos)).erase(e.e_obj -> origin_inc_edges_pos);
			(*(e.e_obj -> dest_vertex.v_obj -> inc_edges_pos)).erase(e.e_obj -> dest_inc_edges_pos);
			edge_collection.erase(e.e_obj -> pos);
		}

};

#endif //ASSIGNMENT5_ADJACENCYLISTDIRECTEDGRAPH_H
